importScripts('brand-config.js');

const BRAND_CONFIG = globalThis.KENEASY_BILICC_CONFIG;
const API_BASE = 'https://api.bilibili.com';
const PAGE_REFERER = 'https://www.bilibili.com';
const DESKTOP_UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

const MESSAGES = Object.freeze({
  fetchSubtitles: 'FETCH_SUBTITLES',
  fetchVideoDetail: 'FETCH_VIDEO_DETAIL',
  fetchFromPage: 'FETCH_API_FROM_PAGE',
});

const MIXIN_KEY_ENC_TAB = [
  46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35,
  27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13,
  37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4,
  22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36, 20, 34, 44, 52,
];

const requestProfiles = Object.freeze({
  page: {
    credentials: 'include',
    headers: {
      Referer: PAGE_REFERER,
      'User-Agent': DESKTOP_UA,
    },
  },
  cdn: {
    credentials: 'include',
    headers: {
      Referer: PAGE_REFERER,
    },
  },
});

function normalizeSubtitleUrl(url) {
  if (!url) return '';
  return url.startsWith('//') ? `https:${url}` : url;
}

function jsonFetch(url, options) {
  return fetch(url, options).then(async (response) => {
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    return response.json();
  });
}

function getMixinKey(imgKey, subKey) {
  const raw = imgKey + subKey;
  return MIXIN_KEY_ENC_TAB.reduce((result, index) => result + raw[index], '').slice(0, 32);
}

function md5(inputString) {
  const hc = '0123456789abcdef';
  function rh(n) {
    let s = '';
    for (let j = 0; j <= 3; j += 1) {
      s += hc.charAt((n >> (j * 8 + 4)) & 0x0f) + hc.charAt((n >> (j * 8)) & 0x0f);
    }
    return s;
  }
  function ad(x, y) {
    const l = (x & 0xffff) + (y & 0xffff);
    const m = (x >> 16) + (y >> 16) + (l >> 16);
    return (m << 16) | (l & 0xffff);
  }
  function rl(n, c) { return (n << c) | (n >>> (32 - c)); }
  function cm(q, a, b, x, s, t) { return ad(rl(ad(ad(a, q), ad(x, t)), s), b); }
  function ff(a, b, c, d, x, s, t) { return cm((b & c) | ((~b) & d), a, b, x, s, t); }
  function gg(a, b, c, d, x, s, t) { return cm((b & d) | (c & (~d)), a, b, x, s, t); }
  function hh(a, b, c, d, x, s, t) { return cm(b ^ c ^ d, a, b, x, s, t); }
  function ii(a, b, c, d, x, s, t) { return cm(c ^ (b | (~d)), a, b, x, s, t); }
  function sb(x) {
    const nblk = ((x.length + 8) >> 6) + 1;
    const blks = new Array(nblk * 16).fill(0);
    let i;
    for (i = 0; i < x.length; i += 1) blks[i >> 2] |= x.charCodeAt(i) << ((i % 4) * 8);
    blks[i >> 2] |= 0x80 << ((i % 4) * 8);
    blks[nblk * 16 - 2] = x.length * 8;
    return blks;
  }

  const utf8String = Array.from(new TextEncoder().encode(inputString))
    .map((byte) => String.fromCharCode(byte))
    .join('');
  const x = sb(utf8String);
  let a = 1732584193;
  let b = -271733879;
  let c = -1732584194;
  let d = 271733878;

  for (let i = 0; i < x.length; i += 16) {
    const olda = a; const oldb = b; const oldc = c; const oldd = d;
    a = ff(a, b, c, d, x[i + 0], 7, -680876936); d = ff(d, a, b, c, x[i + 1], 12, -389564586);
    c = ff(c, d, a, b, x[i + 2], 17, 606105819); b = ff(b, c, d, a, x[i + 3], 22, -1044525330);
    a = ff(a, b, c, d, x[i + 4], 7, -176418897); d = ff(d, a, b, c, x[i + 5], 12, 1200080426);
    c = ff(c, d, a, b, x[i + 6], 17, -1473231341); b = ff(b, c, d, a, x[i + 7], 22, -45705983);
    a = ff(a, b, c, d, x[i + 8], 7, 1770035416); d = ff(d, a, b, c, x[i + 9], 12, -1958414417);
    c = ff(c, d, a, b, x[i + 10], 17, -42063); b = ff(b, c, d, a, x[i + 11], 22, -1990404162);
    a = ff(a, b, c, d, x[i + 12], 7, 1804603682); d = ff(d, a, b, c, x[i + 13], 12, -40341101);
    c = ff(c, d, a, b, x[i + 14], 17, -1502002290); b = ff(b, c, d, a, x[i + 15], 22, 1236535329);
    a = gg(a, b, c, d, x[i + 1], 5, -165796510); d = gg(d, a, b, c, x[i + 6], 9, -1069501632);
    c = gg(c, d, a, b, x[i + 11], 14, 643717713); b = gg(b, c, d, a, x[i + 0], 20, -373897302);
    a = gg(a, b, c, d, x[i + 5], 5, -701558691); d = gg(d, a, b, c, x[i + 10], 9, 38016083);
    c = gg(c, d, a, b, x[i + 15], 14, -660478335); b = gg(b, c, d, a, x[i + 4], 20, -405537848);
    a = gg(a, b, c, d, x[i + 9], 5, 568446438); d = gg(d, a, b, c, x[i + 14], 9, -1019803690);
    c = gg(c, d, a, b, x[i + 3], 14, -187363961); b = gg(b, c, d, a, x[i + 8], 20, 1163531501);
    a = gg(a, b, c, d, x[i + 13], 5, -1444681467); d = gg(d, a, b, c, x[i + 2], 9, -51403784);
    c = gg(c, d, a, b, x[i + 7], 14, 1735328473); b = gg(b, c, d, a, x[i + 12], 20, -1926607734);
    a = hh(a, b, c, d, x[i + 5], 4, -378558); d = hh(d, a, b, c, x[i + 8], 11, -2022574463);
    c = hh(c, d, a, b, x[i + 11], 16, 1839030562); b = hh(b, c, d, a, x[i + 14], 23, -35309556);
    a = hh(a, b, c, d, x[i + 1], 4, -1530992060); d = hh(d, a, b, c, x[i + 4], 11, 1272893353);
    c = hh(c, d, a, b, x[i + 7], 16, -155497632); b = hh(b, c, d, a, x[i + 10], 23, -1094730640);
    a = hh(a, b, c, d, x[i + 13], 4, 681279174); d = hh(d, a, b, c, x[i + 0], 11, -358537222);
    c = hh(c, d, a, b, x[i + 3], 16, -722521979); b = hh(b, c, d, a, x[i + 6], 23, 76029189);
    a = hh(a, b, c, d, x[i + 9], 4, -640364487); d = hh(d, a, b, c, x[i + 12], 11, -421815835);
    c = hh(c, d, a, b, x[i + 15], 16, 530742520); b = hh(b, c, d, a, x[i + 2], 23, -995338651);
    a = ii(a, b, c, d, x[i + 0], 6, -198630844); d = ii(d, a, b, c, x[i + 7], 10, 1126891415);
    c = ii(c, d, a, b, x[i + 14], 15, -1416354905); b = ii(b, c, d, a, x[i + 5], 21, -57434055);
    a = ii(a, b, c, d, x[i + 12], 6, 1700485571); d = ii(d, a, b, c, x[i + 3], 10, -1894986606);
    c = ii(c, d, a, b, x[i + 10], 15, -1051523); b = ii(b, c, d, a, x[i + 1], 21, -2054922799);
    a = ii(a, b, c, d, x[i + 8], 6, 1873313359); d = ii(d, a, b, c, x[i + 15], 10, -30611744);
    c = ii(c, d, a, b, x[i + 6], 15, -1560198380); b = ii(b, c, d, a, x[i + 13], 21, 1309151649);
    a = ii(a, b, c, d, x[i + 4], 6, -145523070); d = ii(d, a, b, c, x[i + 11], 10, -1120210379);
    c = ii(c, d, a, b, x[i + 2], 15, 718787259); b = ii(b, c, d, a, x[i + 9], 21, -343485551);
    a = ad(a, olda); b = ad(b, oldb); c = ad(c, oldc); d = ad(d, oldd);
  }
  return rh(a) + rh(b) + rh(c) + rh(d);
}

async function signWbi(params) {
  const navData = await jsonFetch(`${API_BASE}/x/web-interface/nav`, requestProfiles.page);
  if (navData.code !== 0) {
    throw new Error(`Failed to load WBI keys: ${navData.message || navData.code}`);
  }

  const { img_url: imgUrl, sub_url: subUrl } = navData.data.wbi_img;
  const imgKey = imgUrl.split('/').pop().split('.')[0];
  const subKey = subUrl.split('/').pop().split('.')[0];
  const allParams = { ...params, wts: Math.floor(Date.now() / 1000) };
  const sorted = Object.keys(allParams).sort().reduce((result, key) => {
    result[key] = String(allParams[key]).replace(/[!'()*]/g, '');
    return result;
  }, {});
  const query = new URLSearchParams(sorted).toString();
  return { ...sorted, w_rid: md5(query + getMixinKey(imgKey, subKey)) };
}

async function getVideoInfo(bvid) {
  const url = `${API_BASE}/x/web-interface/view?bvid=${encodeURIComponent(bvid)}`;
  const data = await jsonFetch(url, requestProfiles.page);
  if (data.code !== 0) {
    throw new Error(`Failed to load video detail: ${data.message || data.code}`);
  }
  return data.data;
}

async function fetchViaPage(tabId, url) {
  if (!tabId) return null;
  try {
    const response = await chrome.tabs.sendMessage(tabId, { type: MESSAGES.fetchFromPage, url });
    if (response?.success) return response.data;
    return null;
  } catch (error) {
    console.warn(`${BRAND_CONFIG.logPrefix} Page-context request failed, using service worker fallback.`, error);
    return null;
  }
}

async function getSubtitleList(aid, cid, tabId) {
  let params;
  try {
    params = await signWbi({ aid, cid });
  } catch (error) {
    console.warn(`${BRAND_CONFIG.logPrefix} WBI signing failed, retrying with unsigned params.`, error);
    params = { aid, cid, wts: Math.floor(Date.now() / 1000) };
  }

  const url = `${API_BASE}/x/player/wbi/v2?${new URLSearchParams(params).toString()}`;
  const data = await fetchViaPage(tabId, url) || await jsonFetch(url, requestProfiles.page);
  if (data.code !== 0) {
    throw new Error(`Failed to load subtitles: ${data.message || data.code}`);
  }

  const subtitleData = data?.data?.subtitle || {};
  return {
    subtitles: subtitleData.subtitles || [],
    needLogin: subtitleData.allow_submit === false && data?.data?.need_login_subtitle === true,
  };
}

async function downloadSubtitleJson(subtitleUrl) {
  const url = normalizeSubtitleUrl(subtitleUrl);
  const data = await jsonFetch(url, requestProfiles.cdn);
  return data.body || [];
}

async function handleFetchSubtitles({ bvid, aid, cid, tabId }) {
  let currentAid = aid;
  let currentCid = cid;

  if (!currentAid || !currentCid) {
    const info = await getVideoInfo(bvid);
    currentAid = info.aid;
    currentCid = info.cid;
  }

  const { subtitles, needLogin } = await getSubtitleList(currentAid, currentCid, tabId);
  if (subtitles.length === 0) {
    return { hasSubtitles: false, needLogin, tracks: [] };
  }

  const tracks = [];
  for (const subtitle of subtitles) {
    try {
      tracks.push({
        lan: subtitle.lan,
        lanDoc: subtitle.lan_doc,
        entries: await downloadSubtitleJson(subtitle.subtitle_url),
      });
    } catch (error) {
      console.warn(`${BRAND_CONFIG.logPrefix} Subtitle JSON download failed.`, subtitle.lan, error);
    }
  }

  return { hasSubtitles: tracks.length > 0, needLogin: false, tracks };
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === MESSAGES.fetchSubtitles) {
    handleFetchSubtitles(request)
      .then((data) => sendResponse({ success: true, data }))
      .catch((error) => sendResponse({ success: false, error: error.message || String(error) }));
    return true;
  }

  if (request.type === MESSAGES.fetchVideoDetail) {
    getVideoInfo(request.bvid)
      .then((data) => sendResponse({ success: true, data }))
      .catch((error) => sendResponse({ success: false, error: error.message || String(error) }));
    return true;
  }

  return false;
});
